package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class dasboard extends JFrame implements ActionListener {
    JButton button1,button2,button3,button4,button5,button6,button7,
    button8,button9,button10;
    dasboard(){
        super("Dashboard");
        button1=new JButton("My Account");
        button1.setForeground(Color.black);
        button1.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button1.setBounds(100,200,200,55);
        button1.addActionListener(this);
        add(button1);

        button2=new JButton("Transfer");
        button2.setForeground(Color.black);
        button2.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button2.setBounds(500,200,200,55);
        button2.addActionListener(this);
        add(button2);

        button3=new JButton("Trancation History");
        button3.setForeground(Color.black);
        button3.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button3.setBounds(900,200,200,55);
        button3.addActionListener(this);
        add(button3);

        button4=new JButton("Top Up And Recharge");
        button4.setForeground(Color.black);
        button4.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button4.setBounds(100,300,200,55);
        button4.addActionListener(this);
        add(button4);

        button5=new JButton("Bill Payments");
        button5.setForeground(Color.black);
        button5.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button5.setBounds(500,300,200,55);
        button5.addActionListener(this);
        add(button5);

        button6=new JButton("Debit card Service");
        button6.setForeground(Color.black);
        button6.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button6.setBounds(900,300,200,55);
        button6.addActionListener(this);
        add(button6);

        button7=new JButton("Request");
        button7.setForeground(Color.black);
        button7.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button7.setBounds(100,400,200,55);
        button7.addActionListener(this);
        add(button7);

        button8=new JButton("Sevice");
        button8.setForeground(Color.black);
        button8.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button8.setBounds(500,400,200,55);
        button8.addActionListener(this);
        add(button8);

        button9=new JButton("Quick Transfer");
        button9.setForeground(Color.black);
        button9.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button9.setBounds(900,400,200,55);
        button9.addActionListener(this);
        add(button9);

        button10=new JButton("LogOut");
        button10.setForeground(Color.black);
        button10.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button10.setBounds(1000,50,200,55);
        button10.addActionListener(this);
        add(button10);


        setLayout(null);
        setSize(1120,780);
        setLocation(450,200);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==button1){
            new myaccount();
            setVisible(false);
        } else if (e.getSource()==button2) {
            new transfer();
            setVisible(false);

        } else if (e.getSource()==button3) {
            new history();
            setVisible(true);
        } else if (e.getSource()==button4) {
            new recharge();
            setVisible(true);
        } else if (e.getSource()==button5) {
            new bill();
            setVisible(true);
        }

    }
    public static void main(String[] args) {
        new dasboard();
    }

}
