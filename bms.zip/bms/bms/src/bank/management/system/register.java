package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class register extends JFrame implements ActionListener {
    JButton button11;
    JComboBox box,box2,box3,box4,box5;
    JLabel label1,label2,label3,label4,label5,label6,label7,label8,label9,label10,label11,label12,label13;
    JTextField textField1,textField2,textField3,textField4,textField5,textField6,textField7,textField8,textField9,textField10 ;
    JRadioButton button1,button2,button3,button4,button5,button6,button7;

    register(){
        super("RegisterPage:");
        label1=new JLabel("Create Account");
        label1.setForeground(Color.black);
        label1.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label1.setBounds(300,50,300,45);
        add(label1);

        label2=new JLabel("Name:");
        label2.setForeground(Color.black);
        label2.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label2.setBounds(150,150,300,45);
        add(label2);
        textField1=new JTextField(15);
        textField1.setBounds(460,150,300,45);
        add(textField1);

        label3=new JLabel("Father'sName:");
        label3.setForeground(Color.black);
        label3.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label3.setBounds(150,200,300,45);
        add(label3);
        textField2=new JTextField(15);
        textField2.setBounds(460,200,300,45);
        add(textField2);

        label4=new JLabel("Date of Birth:");
        label4.setForeground(Color.black);
        label4.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label4.setBounds(150,250,300,45);
        add(label4);
        textField3=new JTextField(15);
        textField3.setBounds(460,250,300,45);
        add(textField3);

        label5=new JLabel("Gender");
        label5.setForeground(Color.black);
        label5.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label5.setBounds(150,300,300,45);
        add(label5);
        button1=new JRadioButton("Male");
        button1.setBounds(460,300,50,50);
        add(button1);
        button2=new JRadioButton("Female");
        button2.setBounds(520,300,50,50);
        add(button2);
        button3=new JRadioButton("Others");
        button3.setBounds(600,300,50,50);
        add(button3);
        ButtonGroup group2=new ButtonGroup();
        group2.add(button1);
        group2.add(button2);
        group2.add(button3);

        label6=new JLabel("Martial Status:");
        label6.setForeground(Color.black);
        label6.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label6.setBounds(150,350,300,45);
        add(label6);
        button4=new JRadioButton("Married");
        button4.setBounds(460,350,65,40);
        add(button4);
        button5=new JRadioButton("Single");
        button5.setBounds(520,350,65,40);
        add(button5);
        ButtonGroup group1=new ButtonGroup();
        group1.add(button4);
        group1.add(button5);

        label7=new JLabel("Annual Income:");
        label7.setForeground(Color.black);
        label7.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label7.setBounds(150,400,300,45);
        add(label7);
        textField4=new JTextField(15);
        textField4.setBounds(460,400,300,45);
        add(textField4);

        label8=new JLabel("Person With disability:");
        label8.setForeground(Color.black);
        label8.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label8.setBounds(150,450,300,45);
        add(label8);
        button6=new JRadioButton("Yes");
        button6.setBounds(460,450,65,40);
        add(button6);
        button7=new JRadioButton("No");
        button7.setBounds(550,450,65,40);
        add(button7);
        ButtonGroup group=new ButtonGroup();
        group.add(button6);
        group.add(button7);

        label9=new JLabel("Religion:");
        label9.setForeground(Color.black);
        label9.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label9.setBounds(150,500,300,45);
        add(label9);
        String religion[]={
                "Hindu","Muslim","Sikh","Christian","Others"
        };
        box=new JComboBox(religion);
        box.setBounds(460,500,300,45);
        add(box);

        label10=new JLabel("Category:");
        label10.setForeground(Color.black);
        label10.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label10.setBounds(150,550,300,45);
        add(label10);
        String Category[]={
                "GEN","EBC","OBC","SC","ST"
        };
        box2=new JComboBox(Category);
        box2.setBounds(460,600,300,45);
        add(box2);

        label11=new JLabel("Educational Qualification:");
        label11.setForeground(Color.black);
        label11.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label11.setBounds(150,650,300,45);
        add(label11);
        String Qualification[]={
                "upto 9th class passed","10th class passed","Graduate(Gen.)","Post Graduate(Gen.)","Med.Graduate/Post Graduate",
                "Eng.Graduate/Post Graduate","Law Graduate/Post Graduate","CA/ICWA/MBA/CFA","Computer Degree/Diploma/MCA","Other Professional Degree",
                "Illiterate"
        };
        box3=new JComboBox(Qualification);
        box3.setBounds(460,650,300,45);
        add(box3);

        label12=new JLabel("Occuption Type:");
        label12.setForeground(Color.black);
        label12.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label12.setBounds(150,700,300,45);
        add(label12);
        String occupation[]={
                "State Govt.","Central Govt.","Public Sector Undertaking","Defence","Industrualist","Trade Sect.","Migrant Labour","Contractor","Import/Export Customer",
                "Student","Political/Social Worker"
        };
        box4=new JComboBox(occupation);
        box4.setBounds(460,750,300,45);
        add(box4);

        label13=new JLabel("Nationality:");
        label13.setForeground(Color.black);
        label13.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label13.setBounds(150,800,300,45);
        add(label13);
        textField6=new JTextField(15);
        textField6.setBounds(460,800,300,45);
        add(textField6);

        button11=new JButton("Next");
        button11.setForeground(Color.black);
        button11.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button11.setBounds(900,800,300,55);
        button11.addActionListener(this);
        add(button11);

        setLayout(null);
        setSize(1120,900);
        setLocation(450,200);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        String name=textField1.getText();
        String fname=textField2.getText();
        String dob=textField3.getText();
        String gender=null;
        if(button1.isSelected()){
            gender="Male";
        } else if(button2.isSelected()) {
            gender="Female";
        }
//        else(button3.isSelected()){
//            gender="Other";
//        }
        String martial=null;
        if(button4.isSelected()){
            martial="Married";
        } else if (button5.isSelected()) {
            martial="Single";
        }
        String income=textField4.getText();

        String disability=null;
        if(button6.isSelected()){
            disability="yes";
        }
        else if(button7.isSelected()){
            disability="No";
        }
        String rel = (String) box.getSelectedItem();

        String cat=(String) box2.getSelectedItem();

        String edu=(String) box3.getSelectedItem();

        String occu=(String) box4.getSelectedItem();

        String nat=textField6.getText();
        try{
            if(textField1.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill all the details");
            }else{
                con con1=new con();
                String q="insert into register2 values('"+name+"','"+fname+"','"+dob+"','"+gender+"','"+martial+"','"+income+"','"+disability+"','"+rel+"', '"+cat+"','"+edu+"','"+occu+"','"+nat+"')";
                        con1.state.executeUpdate(q);
                new register2();
                setVisible(false);
            }
        }catch(Exception E){
            E.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new register();
    }
}
