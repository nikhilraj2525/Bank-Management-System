package bank.management.system;
import java.sql.*;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.Statement;

public class con {
    Connection connecct;
    Statement state;
public con(){
    try{
    connecct= DriverManager.getConnection("jdbc:mysql://localhost:3306/banksystem","root","123456");
    state=connecct.createStatement();
    }catch(Exception e){
        e.printStackTrace();
    }
}
}
