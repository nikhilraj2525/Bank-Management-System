package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class transfer extends JFrame implements ActionListener {
    JButton button1;
    JLabel label1,label2,label3;
    JTextField textField1,textField2,textField3;
    transfer(){
        super("Transfer");
        label1=new JLabel("Account Number");
        label1.setForeground(Color.black);
        label1.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label1.setBounds(50,100,300,45);
        add(label1);
        textField1=new JTextField(15);
        textField1.setBounds(350,100,300,45);
        add(textField1);

        label2=new JLabel("IFSC CODE");
        label2.setForeground(Color.black);
        label2.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label2.setBounds(50,150,300,45);
        add(label2);
        textField2=new JTextField(15);
        textField2.setBounds(350,150,300,45);
        add(textField2);

        label3=new JLabel("Enter Amount");
        label3.setForeground(Color.black);
        label3.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label3.setBounds(50,200,300,45);
        add(label3);
        textField3=new JTextField(15);
        textField3.setBounds(350,200,300,45);
        add(textField3);

        button1 =new JButton("Transfer");
       button1. setForeground(Color.black);
        button1.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button1.setBounds(400,400,300,45);
        add(button1);

        setLayout(null);
        setSize(700,500);
        setLocation(450,200);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e){

    }
    public static void main(String[] args) {
        new transfer();
    }
}
