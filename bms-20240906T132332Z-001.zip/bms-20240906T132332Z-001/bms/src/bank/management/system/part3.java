package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class part3 extends JFrame implements ActionListener {
    JCheckBox check1,check2,check3,check4,check5,check6,check7;
    JButton submit;
    JComboBox box1,box2,box3,box4,box5;
    JRadioButton button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,
            button11,button12;
    JLabel label1,label2,label3,label4,label5,label6,label7,label8,label9,label10;
    part3(){
        super("final step");
        label1=new JLabel("Type of Account:");
        label1.setForeground(Color.black);
        label1.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label1.setBounds(150,150,300,45);
        add(label1);
        String TOA[]={
                "Saving Bank Account","BSBDA","BSBDA Small Account","Current Account","Fixed Deposite","Caps Gain"
        };
        box1=new JComboBox(TOA);
        box1.setBounds(430,150,300,45);
        add(box1);

        label2=new JLabel("Mode of Operation:");
        label2.setForeground(Color.black);
        label2.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label2.setBounds(150,200,300,45);
        add(label2);
        String MO[]={
                "Self","Either or Survivor","Former or Survivor","Any one or Survivor","Jointly Operated","Others"
        };
        box2=new JComboBox(MO);
        box2.setBounds(430,200,300,45);
        add(box2);

        label3=new JLabel("Service Required:");
        label3.setForeground(Color.black);
        label3.setFont(new Font("AvantGarde",Font.ITALIC,30));
        label3.setBounds(150,250,300,30);
        add(label3);

        label4=new JLabel(" DEBIT CARD:");
        label4.setForeground(Color.black);
        label4.setFont(new Font("AvantGarde",Font.ITALIC,30));
        label4.setBounds(150,300,300,45);
        add(label4);
        button1=new JRadioButton("Yes");
        button1.setBounds(450,300,65,40);
        add(button1);
        button2=new JRadioButton("No");
        button2.setBounds(550,300,65,40);
        add(button2);
        ButtonGroup group=new ButtonGroup();
        group.add(button1);
        group.add(button2);

        label5=new JLabel(" CHEQUE BOOK:");
        label5.setForeground(Color.black);
        label5.setFont(new Font("AvantGarde",Font.ITALIC,30));
        label5.setBounds(150,350,300,45);
        add(label5);
        button3=new JRadioButton("Yes");
        button3.setBounds(450,350,65,40);
        add(button3);
        button4=new JRadioButton("No");
        button4.setBounds(550,350,65,40);
        add(button4);
        ButtonGroup group1=new ButtonGroup();
        group1.add(button3);
        group1.add(button4);

        label6=new JLabel(" INTERNET BANKING REQUIRED:");
        label6.setForeground(Color.black);
        label6.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label6.setBounds(150,450,300,45);
        add(label6);
        button5=new JRadioButton("Yes");
        button5.setBounds(450,450,65,40);
        add(button5);
        button6=new JRadioButton("No");
        button6.setBounds(550,450,65,40);
        add(button6);
        ButtonGroup group2=new ButtonGroup();
        group2.add(button5);
        group2.add(button6);

        label7=new JLabel(" SMS ALERT:");
        label7.setForeground(Color.black);
        label7.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label7.setBounds(150,500,300,45);
        add(label7);
        button7=new JRadioButton("Yes");
        button7.setBounds(450,500,65,40);
        add(button7);
        button8=new JRadioButton("No");
        button8.setBounds(550,500,65,40);
        add(button8);
        ButtonGroup group3=new ButtonGroup();
        group3.add(button7);
        group3.add(button8);

        label8=new JLabel("3. PHONE BANKING SERVICE:");
        label8.setForeground(Color.black);
        label8.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label8.setBounds(150,550,300,45);
        add(label8);
        button9=new JRadioButton("Yes");
        button9.setBounds(450,550,65,40);
        add(button9);
        button10=new JRadioButton("No");
        button10.setBounds(550,550,65,40);
        add(button10);
        ButtonGroup group4=new ButtonGroup();
        group4.add(button9);
        group4.add(button10);

        label9=new JLabel("3. PASSBOK REQUIRED:");
        label9.setForeground(Color.black);
        label9.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label9.setBounds(150,600,300,45);
        add(label9);

        button11=new JRadioButton("Yes");
        button11.setBounds(450,600,65,40);
        add(button11);
        button12=new JRadioButton("No");
        button12.setBounds(550,600,65,40);
        add(button12);
        ButtonGroup group5=new ButtonGroup();
        group5.add(button11);
        group5.add(button12);



        submit=new JButton("Submit");
        submit.setForeground(Color.black);
        submit.setFont(new Font("AvantGarde",Font.ITALIC,40));
        submit.setBounds(850,600,300,45);
        submit.addActionListener(this);
        add(submit);


        setLayout(null);
        setSize(1120,780);
        setLocation(450,200);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        String TOA = (String) box1.getSelectedItem();
        String MO = (String) box2.getSelectedItem();
        String atm=null;
        if(button1.isSelected()){
            atm="Yes";
        } else if (button2.isSelected()) {
            atm="No";
        }
        String check=null;
        if(button3.isSelected()){
            check="Yes";
        } else if (button4.isSelected()) {
            check="No";
        }
        String ibr=null;
        if(button5.isSelected()){
            ibr="Yes";
        } else if (button6.isSelected()) {
            ibr="No";
        }
        String sms =null;
        if(button7.isSelected()){
            sms="Yes";
        } else if (button8.isSelected()) {
            sms="No";
        }
        String pb=null;
        if(button9.isSelected()){
            pb="Yes";
        } else if (button10.isSelected()) {
            pb="No";
        }
        String pr=null;
        if(button11.isSelected()){
            pr="Yes";
        } else if (button12.isSelected()) {
            pr="No";
        }
        try{
            if( box1.getSelectedItem().equals("")|| box2.getSelectedItem().equals("")){
                JOptionPane.showMessageDialog(null,"Fill all the details");
            }else{
                con con1=new con();
                String q="insert into final values('"+TOA+"','"+MO+"','"+atm+"','"+check+"','"+ibr+"','"+sms+"','"+pb+"','"+pr+"')";
                con1.state.executeUpdate(q);
//                new part3();
               setVisible(false);
                JOptionPane.showMessageDialog(this, "Account information submitted successfully.");

                dispose();
            }
        }catch(Exception E){
            E.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new part3();
    }
}
