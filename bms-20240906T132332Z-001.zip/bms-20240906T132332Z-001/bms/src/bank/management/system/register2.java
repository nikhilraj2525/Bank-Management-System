package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class register2 extends JFrame implements ActionListener {
    JButton button11;
    JTextField textField1,textField2,textField3,textField4,textField5,textField6,textField7,textField8,textField9,textField10;
    JComboBox box,box2,box3;
    JLabel label1,label2,label3,label4,label5,label6,label7,label8,label9,label10,label11,label12;
    register2(){
        super("RegisterPage2:");
        label1=new JLabel("Page2");
        label1.setForeground(Color.black);
        label1.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label1.setBounds(300,20,300,45);
        add(label1);


        label2=new JLabel("Address:");
        label2.setForeground(Color.black);
        label2.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label2.setBounds(150,100,300,45);
        add(label2);
        textField1=new JTextField(15);
        textField1.setBounds(460,100,300,45);
        add(textField1);


        label3=new JLabel("City/Village:");
        label3.setForeground(Color.black);
        label3.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label3.setBounds(150,150,300,45);
        add(label3);
        textField2=new JTextField(15);
        textField2.setBounds(460,150,300,45);
        add(textField2);

        label4=new JLabel("District:");
        label4.setForeground(Color.black);
        label4.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label4.setBounds(150,200,300,45);
        add(label4);
        textField3=new JTextField(15);
        textField3.setBounds(460,200,300,45);
        add(textField3);



        label5=new JLabel("State:");
        label5.setForeground(Color.black);
        label5.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label5.setBounds(150,250,300,45);
        add(label5);
        textField4=new JTextField(15);
        textField4.setBounds(460,250,300,45);
        add(textField4);

        label6=new JLabel("pin:");
        label6.setForeground(Color.black);
        label6.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label6.setBounds(150,300,300,45);
        add(label6);
        textField5=new JTextField(15);
        textField5.setBounds(460,300,300,45);
        add(textField5);

        label7=new JLabel("Mobile Number:");
        label7.setForeground(Color.black);
        label7.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label7.setBounds(150,350,300,45);
        add(label7);
        textField6=new JTextField(15);
        textField6.setBounds(460,350,300,45);
        add(textField6);

        label8=new JLabel("Email Id:");
        label8.setForeground(Color.black);
        label8.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label8.setBounds(150,400,300,45);
        add(label8);
        textField7=new JTextField(15);
        textField7.setBounds(460,400,300,45);
        add(textField7);

        label9=new JLabel("Nominee Name");
        label9.setForeground(Color.black);
        label9.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label9.setBounds(150,450,300,45);
        add(label9);
        textField8=new JTextField(15);
        textField8.setBounds(460,450,300,45);
        add(textField8);

        label10=new JLabel("Relation with Nominee:");
        label10.setForeground(Color.black);
        label10.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label10.setBounds(150,500,300,45);
        add(label10);
        String[] Relation ={
                "Father","Mother","Sister","Brother","Wife","Husband","Child"
        };
        box=new JComboBox(Relation);
        box.setBounds(460,500,300,45);
        add(box);

        label11=new JLabel("AdharCard");
        label11.setForeground(Color.black);
        label11.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label11.setBounds(150,550,300,45);
        add(label11);
        textField9=new JTextField(15);
        textField9.setBounds(460,550,300,45);
        add(textField9);

        label12=new JLabel("PanCard");
        label12.setForeground(Color.black);
        label12.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label12.setBounds(150,600,300,45);
        add(label12);
        textField10=new JTextField(15);
        textField10.setBounds(460,600,300,45);
        add(textField10);

        button11=new JButton("Next");
        button11.setForeground(Color.black);
        button11.setFont(new Font("AvantGarde",Font.ITALIC,40));
        button11.setBounds(900,600,300,55);
        button11.addActionListener(this);
        add(button11);


        setLayout(null);
        setSize(1120,780);
        setLocation(450,200);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e){
        String add=textField1.getText();
        String city=textField2.getText();
        String dist=textField3.getText();
        String state=textField4.getText();
        String pin=textField5.getText();
        String mb=textField6.getText();
        String email=textField7.getText();
        String nname=textField8.getText();
        String rwn = (String) box.getSelectedItem();
        String ac=textField9.getText();
        String pc=textField10.getText();
        try{
            if(textField9.getText().equals("")||textField10.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill all the details");
            }else{
                con con1=new con();
                String q="insert into register3 values('"+add+"','"+city+"','"+dist+"','"+state+"','"+pin+"','"+mb+"','"+email+"','"+nname+"', '"+rwn+"','"+ac+"','"+pc+"')";
                con1.state.executeUpdate(q);
                new part3();
                setVisible(false);
            }
        }catch(Exception E){
            E.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new register2();
    }
}
