package bank.management.system;

import javax.swing.*;

public class history extends JFrame {
    history(){
        setLayout(null);
        setSize(700,500);
        setLocation(450,200);
        setVisible(true);
    }
    public static void main(String[] args) {
        new history();
    }
}
