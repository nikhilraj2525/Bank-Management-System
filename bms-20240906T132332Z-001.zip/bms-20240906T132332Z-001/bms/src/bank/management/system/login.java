package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class login extends JFrame implements ActionListener {
    JLabel label1,label2,label3;
    JTextField textField1;
    JPasswordField passwordField1;
    JButton button1,button2;
    login(){
        super("Bank management System");
//        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("image"));
//        Image i2=i1.getSy
        label1=new JLabel("Welcome to RAJ Bank");
        label1.setForeground(Color.black);
        label1.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label1.setBounds(200,100,500,45);
        add(label1);
        label2=new JLabel("Username");
        label2.setForeground(Color.black);
        label2.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label2.setBounds(200,300,300,45);
        add(label2);
        textField1=new JTextField(15);
        textField1.setBounds(380,300,300,45);
        add(textField1);

        label3=new JLabel("password");
        label3.setForeground(Color.black);
        label3.setFont(new Font("AvantGarde",Font.ITALIC,40));
        label3.setBounds(200,350,300,45);
        add(label3);
        passwordField1=new JPasswordField(15);
        passwordField1.setBounds(380,350,300,45);
        add(passwordField1);

        button1=new JButton("Login");
        button1.setFont(new Font("Arial",Font.ITALIC,14));
        button1.setForeground(Color.black);
        button1.setBounds(340,410,100,30);
        button1.addActionListener(this);
        add(button1);
        button2=new JButton("Register");
        button2.setFont(new Font("Arial",Font.ITALIC,14));
        button2.setForeground(Color.black);
        button2.setBounds(470,420,100,30);
        button2.addActionListener(this);
        add(button2);

        setLayout(null);
    setSize(1120,780);
    setLocation(450,200);
    setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
//        try {
//
//            if( textField1.getText().equals("")|| passwordField1.getT().equals("")){
//                JOptionPane.showMessageDialog(null,"Fill all the details");
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        if(e.getSource()==button1) {
            new dasboard();
            setVisible(true);
        } else if (e.getSource()==button2) {
            new register();
            setVisible(true);
        }
    }

    public static void main(String[] args) {
        new login();
    }
}
