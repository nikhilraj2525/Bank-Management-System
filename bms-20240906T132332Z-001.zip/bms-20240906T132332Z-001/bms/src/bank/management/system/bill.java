package bank.management.system;

import javax.swing.*;

public class bill extends JFrame {
    bill(){
        setLayout(null);
        setSize(700,500);
        setLocation(450,200);
        setVisible(true);
    }
    public static void main(String[] args) {
        new bill();
    }
}
